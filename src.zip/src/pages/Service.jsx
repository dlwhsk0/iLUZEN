import React from "react";

export default function Service() {
  return (
    <div>
      <h1>서비스 탭입니다.</h1>
    </div>
  );
}
