import React from "react";

export default function News() {
  return (
    <div>
      <h1>뉴스 탭입니다.</h1>
    </div>
  );
}
