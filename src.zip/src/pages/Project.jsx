import React from "react";

export default function Project() {
  return (
    <div>
      <h1>프로젝트 탭입니다.</h1>
    </div>
  );
}
