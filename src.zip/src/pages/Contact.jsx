import React from "react";

export default function Contact() {
  return (
    <div>
      <h1>콘택 탭입니다.</h1>
    </div>
  );
}
